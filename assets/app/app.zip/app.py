import flet as ft
from views.views import main

if __name__ == "__main__":
    ft.app(target=main)
